package BinnarySearchWithThread;


import java.util.Scanner;

public class BinarySearchWithThread {
        public static void main(String[] args) {
            Scanner s = new Scanner(System.in);
            System.out.println("Enter the Searching Number:");
            int key = s.nextInt();
            
    }
}
