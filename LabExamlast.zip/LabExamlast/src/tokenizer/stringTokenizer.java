
package tokenizer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author koushik
 */
public class stringTokenizer {
    public static void main(String[] args) throws FileNotFoundException, IOException{
        File file = new File("/home/koushik/Desktop/IO Test/Token.txt");
        File fileOut = new File("/home/koushik/Desktop/IO Test/TokenOut.txt");
        if(!file.exists())
        {
            file.createNewFile(); 
        }
        BufferedReader br = new BufferedReader(new FileReader(file));
        BufferedWriter out = new BufferedWriter(new FileWriter(fileOut));
        String str;
//        Scanner s = new Scanner(System.in);
//        System.out.println("Enter a String:");
//        str = s.nextLine();
        while( (str=br.readLine())!=null)
        {
            StringTokenizer st = new StringTokenizer(str," ,.:;/");
            while(st.hasMoreTokens())
            {
                String temp = st.nextToken();
                String sub1 = temp.substring(0, 1);
                String sub2 = sub1.toUpperCase();
                String result = sub2+temp.substring(1);
                System.out.println(result);
                out.write(result);
                out.newLine();
            }
            
        }
        out.close();
    }
}
